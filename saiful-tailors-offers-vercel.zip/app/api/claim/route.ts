import { NextResponse } from "next/server";
import { createHash, randomInt, randomUUID } from "crypto";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/admin";

const amounts = [40, 60, 80, 100, 120, 140, 160, 180, 200];
const phoneHash = (phone: string) => createHash("sha256").update(phone).digest("hex");

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name || "").trim().slice(0, 80);
    const phone = String(body.phone || "").replace(/\D/g, "");
    if (name.length < 2 || !/^01[3-9]\d{8}$/.test(phone)) return NextResponse.json({ error: "সঠিক নাম ও ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন।" }, { status: 400 });
    const db = adminDb();
    const now = new Date();
    const offers = await db.collection("offers").where("active", "==", true).get();
    const active = offers.docs.find(d => {
      const x = d.data();
      return (!x.startAt || new Date(x.startAt) <= now) && (!x.endAt || new Date(x.endAt) >= now);
    });
    if (!active) return NextResponse.json({ error: "এখন কোনো অফার চালু নেই। নতুন অফারের জন্য অপেক্ষা করুন।" }, { status: 400 });
    const offerData = active.data();
    const hash = phoneHash(phone);
    const customerId = `${active.id}_${hash}`;
    const couponCode = `ST-${randomUUID().slice(0, 8).toUpperCase()}`;
    const discount = amounts[randomInt(amounts.length)];
    const ref = db.collection("customers").doc(customerId);
    const result = await db.runTransaction(async tx => {
      const existing = await tx.get(ref);
      if (existing.exists) return { error: "আপনি ইতিমধ্যে এই মাসের অফার গ্রহণ করেছেন। পরবর্তী অফারে আবার চেষ্টা করুন।" };
      const all = await tx.get(db.collection("customers").where("campaignId", "==", active.id));
      const count = all.docs.filter(d => d.data().status !== "cancelled").length;
      if (count >= Number(offerData.maxUsers || 50)) return { error: "এই অফারের ৫০টি কুপন ইতিমধ্যে পূর্ণ হয়েছে।" };
      tx.create(ref, {
        name, phoneHash: hash, discount, status: "pending", couponCode,
        campaignId: active.id, createdAt: FieldValue.serverTimestamp(),
        deviceId: String(body.deviceId || "").slice(0, 120)
      });
      return { coupon: { name, discount, status: "pending", couponCode, campaignId: active.id } };
    });
    if ("error" in result) return NextResponse.json({ error: result.error }, { status: 409 });
    return NextResponse.json({ ...result, message: "কুপন তৈরি হয়েছে। দোকানে এসে অ্যাডমিন অনুমোদন করাবেন।" });
  } catch {
    return NextResponse.json({ error: "সার্ভারে সমস্যা হয়েছে। পরে আবার চেষ্টা করুন।" }, { status: 500 });
  }
}

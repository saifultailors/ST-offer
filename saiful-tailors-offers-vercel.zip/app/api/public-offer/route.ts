import { NextResponse } from "next/server";
import { adminDb } from "@/lib/admin";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const db = adminDb();
    const now = new Date();
    const snap = await db.collection("offers").where("active", "==", true).get();
    const offerDoc = snap.docs.find(d => {
      const x = d.data();
      return (!x.startAt || new Date(x.startAt) <= now) && (!x.endAt || new Date(x.endAt) >= now);
    });
    if (!offerDoc) return NextResponse.json({ offer: null, customers: [] });
    const offer = { id: offerDoc.id, ...offerDoc.data() } as any;
    const customerSnap = await db.collection("customers").where("campaignId", "==", offerDoc.id).get();
    const customers = customerSnap.docs.map(d => d.data()).filter(x => x.status !== "cancelled")
      .map(x => ({ name: x.name, discount: x.discount, status: x.status, couponCode: x.couponCode, campaignId: x.campaignId }));
    return NextResponse.json({ offer, customers });
  } catch (e) {
    return NextResponse.json({ error: "সার্ভার সেটআপ সম্পূর্ণ হয়নি। অ্যাডমিন Firebase সেটিংস যাচাই করুন।" }, { status: 500 });
  }
}
